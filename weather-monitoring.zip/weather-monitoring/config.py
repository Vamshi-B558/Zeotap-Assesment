API_KEY = '05e1bd7802d1eab18f5d36467fe02453'  # Replace with your OpenWeatherMap API key

CITIES = {
    'Delhi': '1273294',
    'Mumbai': '1275339',
    'Chennai': '1264527',
    'Bangalore': '1277333',
    'Kolkata': '1275004',
    'Hyderabad': '1269843'
}

WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5/weather'

# MySQL Database connection configuration
DB_CONFIG = {
    'user': 'root',
    'password': '18562',
    'host': 'localhost',
    'database': 'weather_db',
}
