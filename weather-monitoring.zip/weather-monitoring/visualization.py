import requests

def fetch_weather_data(city):
    api_key = "05e1bd7802d1eab18f5d36467fe02453"  # Replace with your new API key
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"

    try:
        response = requests.get(url)
        data = response.json()

        if response.status_code == 200:
            # Parse relevant data
            city_name = data.get('name')
            temperature = data['main']['temp']
            feels_like = data['main']['feels_like']
            weather_condition = data['weather'][0]['description']
            timestamp = data['dt']  # or use other timestamp-related data

            print(f"City: {city_name}, Temperature: {temperature}°C, Feels Like: {feels_like}°C, Weather: {weather_condition}")
            return {
                'city': city_name,
                'temperature': temperature,
                'feels_like': feels_like,
                'weather_condition': weather_condition,
                'timestamp': timestamp
            }
        else:
            print(f"Error: {data.get('message', 'Unknown error')}")
            return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

# Example usage
city_name = "Delhi"  # Replace with the city you want to fetch data for
city_data = fetch_weather_data(city_name)
