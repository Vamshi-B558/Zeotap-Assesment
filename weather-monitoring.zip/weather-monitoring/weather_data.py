from turtle import pd
from sqlalchemy import Engine, text  # Make sure to import text

def fetch_weather_data():
    # Query weather data from the database
    query = '''
    SELECT city, temperature, feels_like, weather_condition, DATE(timestamp) as date 
    FROM weather_data
    '''
    with Engine.connect() as connection:
        # Use text() to create an executable statement
        result = connection.execute(text(query))
        df = pd.DataFrame(result.fetchall(), columns=result.keys())
    return df




